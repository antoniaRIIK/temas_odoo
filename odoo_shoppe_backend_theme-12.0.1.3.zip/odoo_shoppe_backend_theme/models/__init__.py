# -*- coding: utf-8 -*-

from . import ir_qweb
from . import ir_ui_menu
from . import res_users
from . import res_company
