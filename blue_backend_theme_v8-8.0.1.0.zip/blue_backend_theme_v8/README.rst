.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Blue Backend Theme V8
=====================

Customize Layout of Backend Theme V8 with Blue Color

Credits
=======

Contributors
------------

* Minh.HQ <minh.hquang09@gmail.com>